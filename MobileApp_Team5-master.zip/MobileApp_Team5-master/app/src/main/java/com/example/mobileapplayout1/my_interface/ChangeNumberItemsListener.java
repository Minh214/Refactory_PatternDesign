package com.example.mobileapplayout1.my_interface;

public interface ChangeNumberItemsListener {
    void changed();
}
