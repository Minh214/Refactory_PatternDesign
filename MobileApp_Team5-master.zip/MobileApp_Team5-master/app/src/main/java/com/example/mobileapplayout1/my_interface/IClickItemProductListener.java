package com.example.mobileapplayout1.my_interface;

import com.example.mobileapplayout1.model.HotSalePhone;

public interface IClickItemProductListener {
    void onClickItemProduct(HotSalePhone phone);
}
